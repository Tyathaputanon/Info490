import lesson
import random

# getting a list of random values
ans = [random.randint(-24,212) for i in range(0,10)]
print(ans)

# no error will be generated if this passes
assert 12 == lesson.minimum_of([12,24,48]), "expected 12"

assert lesson.fancy_min(None, 2) == 2, "should be 2" 
assert lesson.fancy_min(2, None) == 2, "should be 2" 
assert lesson.fancy_min(2, 3) == 2,    "should be 2"