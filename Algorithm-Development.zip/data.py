grade_scale = {
 "A+": {"low": 96, "high":100,"gpa":4.0},
 "A" : {"low": 93, "high":95, "gpa":4.0},
 "A-": {"low": 90, "high":92, "gpa":3.7},
  
 "B+": {"low": 86, "high":89, "gpa":3.3},
 "B" : {"low": 83, "high":85, "gpa":3.0},
 "B-": {"low": 80, "high":82, "gpa":2.7},
  
 "C+": {"low": 76, "high":79, "gpa":2.3},
 "C" : {"low": 73, "high":75, "gpa":2.0},
 "C-": {"low": 70, "high":72, "gpa":1.7},
}

student123 = {
  "id": "smith123",
  "classes" : [
    {"name": "Stats 100",   "points": 88, "credits": 4},
    {"name": "CS 101",      "points": 92, "credits": 3},
    {"name": "History 101", "points": 91, "credits": 3},
    {"name": "Psych 201",   "points": 86, "credits": 4},
  ]
}