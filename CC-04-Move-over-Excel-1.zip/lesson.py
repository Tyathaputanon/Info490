
import numpy as np

def q0(data):
  # total spent
  return np.sum(data['Total'])
  
def q1(data): 
  return np.count_nonzero(data['Type'] == 'Restaurant')
   
def q2(data):
  restaurantTotal = (data[data['Type'] == 'Restaurant'])['Total']
  return np.sum(restaurantTotal)

def q3(data):
  return np.sum(data['Tax'])

def q4(data):  
  groceryTax = (data[data['Type'] == 'Grocery'])['Tax']
  return np.sum(groceryTax)
  
def q5(data): 
  return np.mean(data['Total'])
  
def q6(data): 
  under3 = (data[data['Total'] < 3.00])['Total']
  return np.mean(under3) 
  
def q7(data):
  whole = (data[data['Price']%1 == 0.00])['Price']
  return np.sum(whole) 
   
def q8(data):
  var = [len(name) < 7 for name in data['Merchant']]
  return np.sum(data[var]['Total']) 

def q9(data):
  var = ['Café' in name for name in data['Merchant']]
  return np.count_nonzero(var)
  
def q10(data):
  names = [name for name in data['Merchant'] if 'Café' in name]
  return len(np.unique(names))