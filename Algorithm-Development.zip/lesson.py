def calculate_gpa(gs, student):
  creds = 0 
  pts = 0
  for i in student['classes']:
    creds = creds + i['credits']
    grade = get_letter(gs, i['points'])
    pts = pts + i['credits']*gs[grade]['gpa']
  return pts / creds

def get_letter_grade_v1(grade_scale, gpa):
  pts = gpa*25
  for i in grade_scale.items():
    print (i, pts)
    if (pts >= i[1]['low'] and pts <= i[1]['high']):
      return i[0]
  return 'D'
  
def get_letter(scale, points):
  for grade in scale.items():
    print (grade, points)
    if (points >= grade[1]['low'] and points <= grade[1]['high']):
      return grade[0]
  return 'D'

skip_part3 = True