import lesson
import data


gpa = lesson.calculate_gpa(data.grade_scale, data.student123)
print(gpa, lesson.get_letter_grade_v1(data.grade_scale, gpa))