def fancy_min(a, b):
  if (a is None and b is None):
    return None
  elif a is None:
    return b
  elif b is None or a < b:
    return a
  else:
    return b

def fancy_max(a, b):
  if (a is None and b is None):
    return None
  elif a is None:
    return b
  elif b is None:
    return a
  elif a < b:
    return b
  else:
    return a
    
def minimum_of(num):
  if (num is None or len(num) == 0 ):
    return None
  else:
    n = num[0]
    for i in range(len(num) - 1):
      atm  = fancy_min(num[i], num[i+1])
      if atm < n:
        n = atm
    return n

def maximum_of(num):
  if (num is None or len(num) == 0 ):
    return None
  else:
    n = num[0]
    for i in range(len(num) - 1):
      atm  = fancy_max(num[i], num[i+1])
      if atm > n:
        n = atm
    return n