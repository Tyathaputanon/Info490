import numpy as np
import datetime

import lesson
import math


def test_all():
  
  questions = [lesson.q0, lesson.q1, lesson.q2, 
               lesson.q3, lesson.q4, lesson.q5,
               lesson.q6, lesson.q7, lesson.q8, 
               lesson.q9, lesson.q10]
  
  answers = [ 901.39, 
              33,   407.98, 74.43,
              5.14, 21.98, 
              2.40, 33.0, 35.12,  10,   4]
  
  data = read_data()
  correct_count = 0
  for i, q in enumerate(questions):
    
    result  = q(data)
    if result is not None:
      correct = math.fabs(answers[i] - result)
      correct = (correct < 0.01)
      if (correct):
        correct_count += 1
      else:
        print("{}: {} wanted {}".format(i, result, answers[i]))

    as_str = "{}".format(result)
    if (isinstance(result, np.float)):
      as_str = '{0:,.2f}'.format(result)
    print("Question: {} {}".format(i, as_str))
  
  print("total correct {} out of {}".format(correct_count, len(answers)))
  return correct_count
 

def read_data():
  names = ('U8', 'U50', 'U15', 'float', 'float', 'float')
  data = np.genfromtxt('data.csv', 
                        delimiter=';', 
                        names=True, dtype=names)
  return data
  
def read_data_v0():
  
  def datestr2num(s):
    s = s.decode('utf-8')
    #d = datetime.datetime.strptime(s, '%b %d %Y %I:%M%p')
    return s
  
  names = ('U8', 'U50', 'U15', 'float', 'float', 'float')
  data = np.genfromtxt('data.csv', 
                        converters={'Date': datestr2num},
                        delimiter=';', 
                        names=True, dtype=names)
  return data
