import numpy as np

import util
import lesson
from random import randint 


data = util.read_data()
print(lesson.q10(data))

data = util.read_data()
util.test_all()