# lesson.py

def winner_RPS(p1,p2):
  if p1 == p2:
    return None
  elif p1 == 'rock' and p2 == 'scissors':
    return (p1)
  elif p1 == 'rock' and p2 == 'paper':
    return (p2)
  elif p1 == 'paper' and p2 == 'rock':
    return (p1)
  elif p1 == 'paper' and p2 == 'scissors':
    return (p2)
  elif p1 == 'scissors' and p2 == 'rock':
    return (p2)
  elif p1 == 'scissors' and p2 == 'paper':
    return (p1)
  else:
    return None

