# main.py
import random
import lesson

values = "rock,paper,scissors".split(',')
p1 = random.choice(values)
print(p1)

def test_RPS():
  if lesson.winner_RPS("rock", "rock") != None:
    print ('Test Fail')
    return False
  elif lesson.winner_RPS("rock", "paper") != "paper":
    print ('Test Fail')
    return False
  elif lesson.winner_RPS("rock", "scissors") != "rock":
    print ('Test Fail')
    return False
  elif lesson.winner_RPS("paper", "rock") != "paper":
    print ('Test Fail')
    return False
  elif lesson.winner_RPS("paper", "paper") != None:
    print ('Test Fail')
    return False
  elif lesson.winner_RPS("paper", "scissors") != "scissors":
    print ('Test Fail')
    return False
  elif lesson.winner_RPS("scissors", "rock") != "rock":
    print ('Test Fail')
    return False
  elif lesson.winner_RPS("scissors", "paper") != "scissors":
    print ('Test Fail')
    return False
  elif lesson.winner_RPS("scissors", "scissors") != None:
    print ('Test Fail')
    return False   
  else:
    print ('All tests pass')
    return True